#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "lora.h"
#include "sun_tracker.h"
#include "scene.h"
#include <QTimer>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

typedef unsigned char byte ;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public slots:
    void Timer_loop();
    void confirmPressed();
    void resetPressed();

public:
    MainWindow(unsigned char * Rx_frame,unsigned char * Tx_frame,QWidget *parent = nullptr);
    ~MainWindow();

    void setBackground();
    void setText_settings();
    void setText_White();
    void setDate_Time();

    void setLight_info();
    void setAlarm();

    void setTemp  (int temp);
    void setHumid (int humid);
    void setPress (uint8_t press1, uint8_t press2 );

    void setLight_Living(byte state);
    void setLight_Bath(byte state);
    void setLight_Bed(byte state);
    void setLight_Kit(byte state);
    void setLight_Hall(byte state);
    void setLight_Gar(byte state);

    void setFan(byte state);
    void setCM_Alarm(byte state);
    void setFlood(byte state);
    void setDoor(byte state);
    void setCar(byte state);

    void setHours(uint8_t hours, uint8_t minutes, uint8_t seconds);
    void setDate(uint8_t days, uint8_t months, uint8_t years);

    double ex=0;
    double ey=0;
    double t=0;
    int w ;
    int h ;
    unsigned char * rx_frame;
    unsigned char * tx_frame;

    uint8_t alarm_hours=0;
    uint8_t alarm_minutes=0;
    uint8_t alarm_day=0;
    uint8_t alarm_month=0;

    SunTracker3D *ST; //!< Wskaźnik na scene 3D.
    Scene *objectWidget;//!< Wskaźnik na widget sceny.


private:
    Ui::MainWindow *ui;

    QTimer qtimer;

};
#endif // MAINWINDOW_H

#ifndef SUN_TRACKER_H
#define SUN_TRACKER_H

#include<Qt3DRender/QSceneLoader>
#include <QVector3D>
#include <QWidget>
#include <QCheckBox>
#include <QPushButton>
#include <QLabel>
#include <Qt3DCore/QTransform>
#include <Qt3DExtras/QDiffuseMapMaterial>
#include <Qt3DRender/QCamera>
#include <Qt3DRender/QTextureImage>


/*!
 * \class Object_Scene
 * \brief Klasa ma na celu stworzenie scene, kamerę, oświetlenie dla wybranego modelu 3D
 */
class SunTracker3D : public QWidget
{
    Q_OBJECT
public:

    explicit SunTracker3D(QWidget *parent = nullptr);


    void SetObj(Qt3DCore::QEntity* object, QVector3D *vec);
    void SetObjWhite(Qt3DCore::QEntity* object, QVector3D *vec);
    void SetObjLightBlue(Qt3DCore::QEntity* object, QVector3D *vec);

    Qt3DCore::QTransform * getLocTransform();

    void TopSerwoRotate(double angle);
    void BottomSerwoRotate(double angle);

    QVector3D *platformPosition = new QVector3D(-1.55-0.35,-1-0.13-2.12,3.9);
    QVector3D *platformBackPosition = new QVector3D(-1.55-0.35,-1,3.9);
    QVector3D *topMiniPosition = new QVector3D(-1.55,0,3.9);
    QVector3D *topPosition = new QVector3D(0,0,4.4);
    QVector3D *bottomPosition = new QVector3D(0,0,2.1);
    QVector3D *bottomMiniPosition = new QVector3D(0,0.5,0.35+0.2);
    QVector3D *bottomGearPosition = new QVector3D(0,0,0.1);
    QVector3D *basePosition = new QVector3D(0,0,-0.1);


    QVector3D *platformSize = new QVector3D(9.5,0.27,4.85);
    QVector3D *platformBackSize = new QVector3D(0.27,4.25,1.9);
    QVector3D *topMiniSize = new QVector3D(0.7,0.3,0.3);
    QVector3D *topSize = new QVector3D(2.4,1.2,2.2);
    QVector3D *bottomSize = new QVector3D(1.2,2.2,2.4);
    QVector3D *bottomMiniSize = new QVector3D(0.3,0.3,0.7);
    QVector3D *bottomGearSize = new QVector3D(0.5,2.2,0.2);
    QVector3D *baseSize = new QVector3D(9,9,0.2);


    Qt3DCore::QTransform *platformTran = new Qt3DCore::QTransform();
    Qt3DCore::QTransform *platformBackTran = new Qt3DCore::QTransform();

    Qt3DCore::QTransform *bottomGearTran = new Qt3DCore::QTransform();
    Qt3DCore::QTransform *bottomMiniTran = new Qt3DCore::QTransform();
    Qt3DCore::QTransform *bottomTran = new Qt3DCore::QTransform();

    Qt3DCore::QTransform *topMiniTran = new Qt3DCore::QTransform();
    Qt3DCore::QTransform *topTran = new Qt3DCore::QTransform();
    Qt3DCore::QTransform *baseTran = new Qt3DCore::QTransform();

private:

    Qt3DCore::QEntity *rootEntity; //!< Główny obiekt sceny do której podpięte są wszystkie gałęzie które są elementami klasy Qt3D.
    Qt3DRender::QCamera *cameraEntity;//!<Kamera sceny.


    Qt3DCore::QTransform *local_transform = new Qt3DCore::QTransform(); //!< transformacja obiektu.


};

#endif // OBJECT_VIEW_SCENE_H

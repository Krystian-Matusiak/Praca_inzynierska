#ifndef OBJECT_VIEW_H
#define OBJECT_VIEW_H


#include <QWidget>
#include "sun_tracker.h"

namespace Ui {
class Scene;
}

/*!
 * \class Object_Widget
 * \brief Klasa Object_Widget która zawiera w sobie widget odpowiedzialny za wyświetlenie sceny 3D
 */
class Scene : public QWidget
{
    Q_OBJECT

public:
    explicit Scene(QWidget *parent = nullptr);

    ~Scene();

    /*!
     * \brief Funkcja zwraca wskaźnik do QWidgetu stworzonego w formularzu "object_widget.ui".
     * \return Wskaźnik na scene.
     */
    SunTracker3D *renderSunT();
public slots:


private:
    Ui::Scene *ui;
};

#endif // OBJECT_VIEW_H

#include "sun_tracker.h"

#include <Qt3DExtras>
#include <Qt3DCore/QEntity>
#include <QTransform>
#include <QScreen>
#include <QLayout>
#include <QCheckBox>
#include <QScreen>
#include <Qt3DCore/QTransform>
#include <Qt3DRender/QPointLight>
#include <Qt3DExtras>
#include <QFirstPersonCameraController>
#include <QPushButton>
#include <QLabel>
#include <Qt3DExtras/QForwardRenderer>


SunTracker3D::SunTracker3D(QWidget *parent)
    : QWidget(parent)
{
    // VIEW
    Qt3DExtras::Qt3DWindow *view = new Qt3DExtras::Qt3DWindow();
    view->defaultFrameGraph()->setClearColor(QColor(200, 200, 255));
    QWidget *container = QWidget::createWindowContainer(view);

    // CONTAINER
    QSize screenSize = view->screen()->size();
    container->setMinimumSize(QSize(400, 400));
    container->setMaximumSize(screenSize);
    container->setFocusPolicy(Qt::NoFocus);

    // ROOT ENTITY
    rootEntity = new Qt3DCore::QEntity();

    // CAMERA
    cameraEntity = view->camera();


    cameraEntity->lens()->setPerspectiveProjection(45.0f, 16.0f/9.0f, 0.1f, 1000.0f);
    cameraEntity->setPosition(QVector3D(5, -10, 5.0f));
    cameraEntity->setUpVector(QVector3D(1, 1, 1));
    cameraEntity->setViewCenter(QVector3D(0,0 , 20));

    // LIGHT
    Qt3DCore::QEntity *lightEntity = new Qt3DCore::QEntity(rootEntity);
    Qt3DRender::QPointLight *light = new Qt3DRender::QPointLight(lightEntity);
    light->setColor("white");
    light->setIntensity(1);
    lightEntity->addComponent(light);
    Qt3DCore::QTransform *lightTransform = new Qt3DCore::QTransform(lightEntity);
    lightTransform->setTranslation(QVector3D(130,-100, 45));
    lightEntity->addComponent(lightTransform);

    Qt3DCore::QEntity *lightEntity2 = new Qt3DCore::QEntity(rootEntity);
    Qt3DRender::QPointLight *light2 = new Qt3DRender::QPointLight(lightEntity);
    light->setColor("white");
    light->setIntensity(1);
    lightEntity->addComponent(light);
    Qt3DCore::QTransform *lightTransform2 = new Qt3DCore::QTransform(lightEntity);
    lightTransform->setTranslation(QVector3D(80,-100, 75));
    lightEntity->addComponent(lightTransform);

    // For camera controls
    Qt3DExtras::QOrbitCameraController *camController = new Qt3DExtras::QOrbitCameraController(rootEntity);
    camController->setCamera(cameraEntity);

    cameraEntity = view->camera();

    //     For the Blender model:
    //         X+ -> right
    //         Y+ -> away
    //         Z+ -> up
    cameraEntity = view->camera();





    // OBJECTS CREATION

    Qt3DCore::QEntity* base = new Qt3DCore::QEntity();
    SetObjWhite(base,baseSize);

    Qt3DCore::QEntity* bottom = new Qt3DCore::QEntity();
    Qt3DCore::QEntity* bottomMini = new Qt3DCore::QEntity();
    Qt3DCore::QEntity* bottomGear = new Qt3DCore::QEntity();
    SetObjLightBlue(bottom,bottomSize);
    SetObjWhite(bottomMini,bottomMiniSize);
    SetObjWhite(bottomGear,bottomGearSize);

    Qt3DCore::QEntity* top = new Qt3DCore::QEntity();
    Qt3DCore::QEntity* topMini = new Qt3DCore::QEntity();
    SetObjLightBlue(top,topSize);
    SetObjWhite(topMini,topMiniSize);

    Qt3DCore::QEntity* platform = new Qt3DCore::QEntity();
    Qt3DCore::QEntity* platformBack = new Qt3DCore::QEntity();
    SetObj(platform,platformSize);
    SetObjWhite(platformBack,platformBackSize);



    platform->addComponent(platformTran);
    platformBack->addComponent(platformBackTran);

    top->addComponent(topTran);
    topMini->addComponent(topMiniTran);
    bottom->addComponent(bottomTran);
    bottomMini->addComponent(bottomMiniTran);
    bottomGear->addComponent(bottomGearTran);
    base->addComponent(local_transform);

//    topTran->setTranslation(QVector3D(0,0, 2.3));
//    platformTran->setTranslation(QVector3D(0,5, 5));

    platformTran->setTranslation(*platformPosition);
    platformBackTran->setTranslation(*platformBackPosition);
    topMiniTran->setTranslation(*topMiniPosition);
    topTran->setTranslation(*topPosition);
    bottomTran->setTranslation(*bottomPosition);
    bottomMiniTran->setTranslation(*bottomMiniPosition);
    bottomGearTran->setTranslation(*bottomGearPosition);
    baseTran->setTranslation(*basePosition);


//    local_transform->setTranslation(QVector3D(1,1, 1));

    view->setRootEntity(rootEntity);
    this->setLayout(new QGridLayout);
    layout()->addWidget(container);
}

void SunTracker3D::SetObj(Qt3DCore::QEntity* object, QVector3D *vec)
{
    Qt3DExtras::QCuboidMesh* platformFigure;
    Qt3DExtras::QPhongMaterial *manipulatorMaterial = new Qt3DExtras::QPhongMaterial();
    manipulatorMaterial->setDiffuse(QColor(100,100,250));
    platformFigure = new Qt3DExtras::QCuboidMesh();
    platformFigure->setXExtent(vec->x());
    platformFigure->setYExtent(vec->y());
    platformFigure->setZExtent(vec->z());

    object->addComponent(platformFigure);
    object->addComponent(manipulatorMaterial);
    object->setParent(rootEntity);
}

void SunTracker3D::SetObjLightBlue(Qt3DCore::QEntity* object, QVector3D *vec)
{
    Qt3DExtras::QCuboidMesh* platformFigure;
    Qt3DExtras::QPhongMaterial *manipulatorMaterial = new Qt3DExtras::QPhongMaterial();
    manipulatorMaterial->setDiffuse(QColor(120,120,250));
    platformFigure = new Qt3DExtras::QCuboidMesh();
    platformFigure->setXExtent(vec->x());
    platformFigure->setYExtent(vec->y());
    platformFigure->setZExtent(vec->z());

    object->addComponent(platformFigure);
    object->addComponent(manipulatorMaterial);
    object->setParent(rootEntity);
}

void SunTracker3D::SetObjWhite(Qt3DCore::QEntity* object, QVector3D *vec)
{
    Qt3DExtras::QCuboidMesh* platformFigure;
    Qt3DExtras::QPhongMaterial *manipulatorMaterial = new Qt3DExtras::QPhongMaterial();
    manipulatorMaterial->setDiffuse(QColor(250,250,250));
    platformFigure = new Qt3DExtras::QCuboidMesh();
    platformFigure->setXExtent(vec->x());
    platformFigure->setYExtent(vec->y());
    platformFigure->setZExtent(vec->z());

    object->addComponent(platformFigure);
    object->addComponent(manipulatorMaterial);
    object->setParent(rootEntity);
}


Qt3DCore::QTransform * SunTracker3D::getLocTransform()
{
    return local_transform;
}


void SunTracker3D::TopSerwoRotate(double angle)
{
    topTran->rotate(angle);
}

void SunTracker3D::BottomSerwoRotate(double angle)
{
    bottomTran->rotate(angle);
}

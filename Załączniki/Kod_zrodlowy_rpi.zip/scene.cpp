#include "scene.h"
#include "ui_scene.h"

#include <QDebug>
Scene::Scene(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Scene)
{
    ui->setupUi(this);
}

Scene::~Scene()
{
    delete ui;
}


SunTracker3D *Scene::renderSunT()
{
    return ui->renderSunT;
}

 #include "mainwindow.h"
#include "ui_mainwindow.h"
#include <iostream>
#include <QGraphicsBlurEffect>
#include <iostream>
#include <math.h>

#define WIDTH_ROOM  70
#define HEIGHT_ROOM 70

#define WIDTH  80
#define HEIGHT 80

#define WIDTH_ALARM  50
#define HEIGHT_ALARM 50

using namespace std;

void MainWindow::Timer_loop(){
    qtimer.start();
    if( rx_frame[0] == 0x02 ){
        setLight_Kit    ( (rx_frame[10]>>4)&1 );
        setLight_Hall   ( (rx_frame[10]>>3)&1 );
        setLight_Gar    ( (rx_frame[10]>>2)&1 );

        setCM_Alarm     ( (rx_frame[10]>>1)&1 );
        setDoor         ( (rx_frame[10]>>5)&1 );
        setCar          (   rx_frame[10]&1);

        setTemp         (rx_frame[3]);
        setPress        (rx_frame[1], rx_frame[2]);

        setHours        (rx_frame[4],rx_frame[5],rx_frame[6]);
        setDate         (rx_frame[7],rx_frame[8],rx_frame[9]);
    }

    if( rx_frame[0] == 0x03 ){
        setLight_Living ( (rx_frame[2]>>5)&1 );
        setLight_Bath   ( (rx_frame[2]>>4)&1 );
        setLight_Bed    ( (rx_frame[2]>>3)&1 );

        setHumid        (rx_frame[1]);
        setFan          (rx_frame[2]&1);

        if(rx_frame[1] > 50)
            setFlood(1);
        else
            setFlood(0);

        if( (rx_frame[2]>>2) & 1 )
            resetPressed();
    }

    auto pos = ST->basePosition;
    ST->getLocTransform()->setTranslation(rx_frame[13]);
    ST->topMiniTran->setTranslation(rx_frame[11]);

    qtimer.start();
}


MainWindow::MainWindow(unsigned char * Rx_frame, unsigned char * Tx_frame, QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    rx_frame = Rx_frame;
    tx_frame = Tx_frame;


    objectWidget = ui->scene;
    ST = objectWidget->renderSunT();

    ui->Tabs->setTabText(0,"Home");
    ui->Tabs->setTabText(1,"Livingroom and Kitchen");
    ui->Tabs->setTabText(2,"Hall and Bathroom");
    ui->Tabs->setTabText(3,"Bedroom and Garage");
    ui->Tabs->setTabText(4,"Sun Tracker");

    setBackground();
    setText_settings();
    setDate_Time();
    setText_White();
    setLight_info();

    setTemp(23);
    setHumid(13);
    setPress(0x40,0x03);

    ui->Tabs->setWindowOpacity(0.0);
    ui->Tabs->setAutoFillBackground(false);
    ui->Tab_Home->setWindowOpacity(0.0);

    connect( &qtimer,SIGNAL(timeout()),this,SLOT(Timer_loop()));
    connect( ui->Button_Confirm,SIGNAL(pressed()),this,SLOT(confirmPressed()));
    connect( ui->Button_Reset,SIGNAL(pressed()),this,SLOT(resetPressed()));

    qtimer.setInterval(50);
    qtimer.setSingleShot(true);
    qtimer.start();

}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::confirmPressed(){
    alarm_hours     = ui->Spinbox_Hours->value();
    alarm_minutes   = ui->Spinbox_Minutes->value();
    alarm_day       = ui->Spinbox_Day->value();
    alarm_month     = ui->Spinbox_Month->value();

    tx_frame[2]=alarm_day;
    tx_frame[3]=alarm_month;
    tx_frame[4]=alarm_hours;
    tx_frame[5]=alarm_minutes;

}

void MainWindow::resetPressed(){
    alarm_hours     = 0;
    alarm_minutes   = 0;
    alarm_day       = 0;
    alarm_month     = 0;

    tx_frame[2]=alarm_day;
    tx_frame[3]=alarm_month;
    tx_frame[4]=alarm_hours;
    tx_frame[5]=alarm_minutes;
}

void MainWindow::setBackground(){

    this->w = this->width();
    this->h = this->height();

    QImage img("../piSmartHome/IMAGES/Blurred_background");
    QImage IMG = img.scaled( this->w , this->h , Qt::IgnoreAspectRatio, Qt::FastTransformation);

    QPalette palette;
    palette.setBrush(QPalette::Background, IMG);

    this->setAutoFillBackground(true);
    this->setPalette(palette);

    ui->Spinbox_Day->setRange(1,31);
    ui->Spinbox_Month->setRange(1,12);
    ui->Spinbox_Hours->setRange(0,23);
    ui->Spinbox_Minutes->setRange(0,59);

}

void MainWindow::setText_settings(){

    ui->Tabs->setStyleSheet("QTabBar::tab { background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255);  }");

    QImage img("../piSmartHome/IMAGES/Blurred_background");
    QImage IMG = img.scaled( this->w , this->h , Qt::IgnoreAspectRatio, Qt::FastTransformation);
    QPalette palette;
    palette.setBrush(QPalette::Background, IMG);

    ui->Tabs->setAutoFillBackground(true);
    ui->Tabs->setPalette(palette);

    ui->Tab_Home->setAutoFillBackground(true);
    ui->Tab_Home->setPalette(palette);
    ui->Tab_Liv_Kit->setAutoFillBackground(true);
    ui->Tab_Liv_Kit->setPalette(palette);
    ui->Tab_Bath_Hall->setAutoFillBackground(true);
    ui->Tab_Bath_Hall->setPalette(palette);
    ui->Tab_Bed_Gar->setAutoFillBackground(true);
    ui->Tab_Bed_Gar->setPalette(palette);
    ui->Tab_Sun->setAutoFillBackground(true);
    ui->Tab_Sun->setPalette(palette);

    ui->Frame_Date->setStyleSheet("background-color: rgb(0, 0, 0,90);");
    ui->Frame_Hours->setStyleSheet("background-color: rgb(0, 0, 0,90);");
    ui->Frame_Minutes->setStyleSheet("background-color: rgb(0, 0, 0,90);");
    ui->Frame_Seconds->setStyleSheet("background-color: rgb(0, 0, 0,90);");

    ui->Frame_Livingroom->setStyleSheet     ("background-color: rgb(0, 0, 0, 100);");
    ui->Frame_Bathroom->setStyleSheet       ("background-color: rgb(0, 0, 0, 100);");
    ui->Frame_Bedroom->setStyleSheet        ("background-color: rgb(0, 0, 0, 100);");
    ui->Frame_Kitchen->setStyleSheet        ("background-color: rgb(0, 0, 0, 100);");
    ui->Frame_Hall->setStyleSheet           ("background-color: rgb(0, 0, 0, 100);");
    ui->Frame_Garage->setStyleSheet         ("background-color: rgb(0, 0, 0, 100);");

    ui->Frame_Temp->setStyleSheet           ("background-color: rgb(0, 0, 0, 100);");
    ui->Frame_Humid->setStyleSheet          ("background-color: rgb(0, 0, 0, 100);");
    ui->Frame_Press->setStyleSheet          ("background-color: rgb(0, 0, 0, 100);");

    ui->Frame_Livingroom_2->setStyleSheet   ("background-color: rgb(0, 0, 0, 100);");
    ui->Frame_Fan->setStyleSheet            ("background-color: rgb(0, 0, 0, 100);");
    ui->Frame_Kitchen_2->setStyleSheet      ("background-color: rgb(0, 0, 0, 100);");
    ui->Frame_CM_Sensor->setStyleSheet      ("background-color: rgb(0, 0, 0, 100);");
    ui->Frame_Text_CMS->setStyleSheet       ("background-color: rgb(0, 0, 0, 0);");

    ui->Frame_Bathroom_2->setStyleSheet     ("background-color: rgb(0, 0, 0, 100);");
    ui->Frame_Hall_2->setStyleSheet         ("background-color: rgb(0, 0, 0, 100);");
    ui->Frame_Flood->setStyleSheet          ("background-color: rgb(0, 0, 0, 100);");

    ui->Frame_Garage_2->setStyleSheet       ("background-color: rgb(0, 0, 0, 100);");
    ui->Frame_Bedroom_2->setStyleSheet      ("background-color: rgb(0, 0, 0, 100);");
    ui->Frame_Door->setStyleSheet           ("background-color: rgb(0, 0, 0, 100);");
    ui->Frame_Alarm_Time->setStyleSheet     ("background-color: rgb(0, 0, 0, 100);");
    ui->Frame_CarAl->setStyleSheet          ("background-color: rgb(0, 0, 0, 100);");


    setAlarm();


    /*****************************************************************************/
    // Setting image to QPixmap and scaling

    QPixmap img_kitchen("../piSmartHome/IMAGES/kitchen");
    QPixmap img_livingroom("../piSmartHome/IMAGES/livingroom");
    QPixmap img_bathroom("../piSmartHome/IMAGES/bathroom");
    QPixmap img_hall("../piSmartHome/IMAGES/hall");
    QPixmap img_bedroom("../piSmartHome/IMAGES/bedroom");
    QPixmap img_garage("../piSmartHome/IMAGES/garage");

    QPixmap img_temp("../piSmartHome/IMAGES/temperature");
    QPixmap img_humid("../piSmartHome/IMAGES/humidity");
    QPixmap img_press("../piSmartHome/IMAGES/pressure");

    QPixmap img_fan("../piSmartHome/IMAGES/ceiling-fan");
    QPixmap img_fire("../piSmartHome/IMAGES/cmsensor");

    QPixmap img_flood("../piSmartHome/IMAGES/flood");

    QPixmap img_door("../piSmartHome/IMAGES/door");
    QPixmap img_car("../piSmartHome/IMAGES/car");

    QPixmap IMG_kitchen    = img_kitchen.scaled     ( WIDTH_ROOM , HEIGHT_ROOM , Qt::IgnoreAspectRatio, Qt::FastTransformation);
    QPixmap IMG_livingroom = img_livingroom.scaled  ( WIDTH_ROOM , HEIGHT_ROOM , Qt::IgnoreAspectRatio, Qt::FastTransformation);
    QPixmap IMG_bathroom   = img_bathroom.scaled    ( WIDTH_ROOM , HEIGHT_ROOM , Qt::IgnoreAspectRatio, Qt::FastTransformation);
    QPixmap IMG_hall       = img_hall.scaled        ( WIDTH_ROOM , HEIGHT_ROOM , Qt::IgnoreAspectRatio, Qt::FastTransformation);
    QPixmap IMG_bedroom    = img_bedroom.scaled     ( WIDTH_ROOM , HEIGHT_ROOM , Qt::IgnoreAspectRatio, Qt::FastTransformation);
    QPixmap IMG_garage     = img_garage.scaled      ( WIDTH_ROOM , HEIGHT_ROOM , Qt::IgnoreAspectRatio, Qt::FastTransformation);

    QPixmap IMG_temp       = img_temp.scaled        ( WIDTH , HEIGHT , Qt::IgnoreAspectRatio, Qt::FastTransformation);
    QPixmap IMG_humid      = img_humid.scaled       ( WIDTH , HEIGHT , Qt::IgnoreAspectRatio, Qt::FastTransformation);
    QPixmap IMG_press      = img_press.scaled       ( WIDTH , HEIGHT , Qt::IgnoreAspectRatio, Qt::FastTransformation);

    QPixmap IMG_fan        = img_fan.scaled         ( WIDTH_ROOM , HEIGHT_ROOM , Qt::IgnoreAspectRatio, Qt::FastTransformation);
    QPixmap IMG_fire       = img_fire.scaled        ( WIDTH_ROOM , HEIGHT_ROOM , Qt::IgnoreAspectRatio, Qt::FastTransformation);

    QPixmap IMG_flood      = img_flood.scaled       ( WIDTH_ROOM , HEIGHT_ROOM , Qt::IgnoreAspectRatio, Qt::FastTransformation);

    QPixmap IMG_door       = img_door.scaled        ( WIDTH_ROOM , HEIGHT_ROOM , Qt::IgnoreAspectRatio, Qt::FastTransformation);
    QPixmap IMG_car       = img_car.scaled          ( WIDTH_ROOM*1.5 , HEIGHT_ROOM*1.5 , Qt::IgnoreAspectRatio, Qt::FastTransformation);


    /*****************************************************************************/
    // Setting QPixmap to Labels

    ui->Label_Livingroom->setPixmap(IMG_livingroom);
    ui->Label_Kitchen->setPixmap(IMG_kitchen);
    ui->Label_Bathroom->setPixmap(IMG_bathroom);
    ui->Label_Hall->setPixmap(IMG_hall);
    ui->Label_Bedroom->setPixmap(IMG_bedroom);
    ui->Label_Garage->setPixmap(IMG_garage);

    ui->Label_Temp->setPixmap(IMG_temp);
    ui->Label_Humid->setPixmap(IMG_humid);
    ui->Label_Press->setPixmap(IMG_press);

    ui->Label_Livingroom_2->setPixmap(IMG_livingroom);
    ui->Label_Fan->setPixmap(IMG_fan);
    ui->Label_Kitchen_2->setPixmap(IMG_kitchen);
    ui->Label_CM_Sensor->setPixmap(IMG_fire);

    ui->Label_Hall_2->setPixmap(IMG_hall);
    ui->Label_Bathroom_2->setPixmap(IMG_bathroom);

    ui->Label_Flood->setPixmap(IMG_flood);

    ui->Label_Bedroom_2->setPixmap(IMG_bedroom);
    ui->Label_Garage_2->setPixmap(IMG_garage);
    ui->Label_Door->setPixmap(IMG_door);
    ui->Label_CarAl->setPixmap(IMG_car);


    ui->Label_Livingroom->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Label_Kitchen->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Label_Bathroom->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Label_Hall->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Label_Bedroom->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Label_Garage->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");

    ui->Label_Temp->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Label_Humid->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Label_Press->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");

    ui->Label_Livingroom_2->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Label_Fan->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Label_Kitchen_2->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Label_CM_Sensor->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");

    ui->Label_Hall_2->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Label_Bathroom_2->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");

    ui->Label_Flood->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");

    ui->Label_Bedroom_2->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Label_Garage_2->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Label_Door->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Label_CarAl->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");

    ui->Text_Set_Alarm->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Text_Set_Day->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Text_Set_Month->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Text_Set_Hours->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Text_Set_Minutes->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Spinbox_Day->setStyleSheet("QSpinBox {background-color: rgb(0, 0, 0,0);color: rgb(255,255,255,255); } ");
    ui->Spinbox_Month->setStyleSheet("QSpinBox {background-color: rgb(0, 0, 0,0);color: rgb(255,255,255,255); } ");
    ui->Spinbox_Hours->setStyleSheet("QSpinBox {background-color: rgb(0, 0, 0,0);color: rgb(255,255,255,255); } ");
    ui->Spinbox_Minutes->setStyleSheet("QSpinBox {background-color: rgb(0, 0, 0,0);color: rgb(255,255,255,255); } ");
    ui->Button_Confirm->setStyleSheet("QPushButton {background-color: rgb(255, 255, 255,0);color: rgb(0,0,0,255); } ");


}

void MainWindow::setText_White(){

    ui->Time_Date->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Time_Hours->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Time_Minutes->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Time_Seconds->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");

    ui->Text_Temp->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Value_Temp->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Text_Humidity->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Value_Humidity->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Text_Press->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Value_Press->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");

    ui->Value_Livingroom->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Value_Kitchen->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Value_Bathroom->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Value_Hall->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Value_Bedroom->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Value_Garage->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");

    ui->Text_Livingroom->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Text_Kitchen->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Text_Bathroom->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Text_Hall->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Text_Bedroom->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Text_Garage->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");

    /*****************************************************/
    // Livingroom and Kitchen tab

    ui->Value_Livingroom_2->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Text_Livingroom_2->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");

    ui->Value_Fan->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Text_Fan->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");

    ui->Value_Kitchen_2->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Text_Kitchen_2->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");

    ui->Value_CM_Sensor->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Text_CMS1->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Text_CMS2->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Text_CMS3->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");

    /*****************************************************/
    // Bathroom and Hall tab

    ui->Value_Bathroom_2->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Text_Bathroom_2->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");

    ui->Value_Hall_2->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Text_Hall_2->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");

    ui->Value_Flood->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Text_Flood->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");

    /*****************************************************/
    // Bedroom and Garage tab

    ui->Text_Bedroom_2->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Value_Bedroom_2->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");

    ui->Text_Garage_2->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Value_Garage_2->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");

    ui->Text_Door->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Value_Door->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");

    ui->Text_CarAl->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Value_CarAl->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");

}


void MainWindow::setLight_info(){
    QString onoff;
    onoff = "OFF";
    ui->Value_Livingroom->setText("Lights: " +  onoff);
    ui->Value_Kitchen->setText("Lights: " +  onoff);
    ui->Value_Bathroom->setText("Lights: " +  onoff);
    ui->Value_Hall->setText("Lights: " +  onoff);
    ui->Value_Bedroom->setText("Lights: " +  onoff);
    ui->Value_Garage->setText("Lights: " +  onoff);

    ui->Value_Livingroom_2->setText("Lights: " +  onoff);
    ui->Value_Fan->setText("State: " +  onoff);

    ui->Value_Kitchen_2->setText("Lights: " +  onoff);
    ui->Value_CM_Sensor->setText("State: " +  onoff);

    ui->Value_Bathroom_2->setText("Lights: " +  onoff);
    ui->Value_Hall_2->setText("Lights: " +  onoff);

    ui->Value_Flood->setText("State: " +  onoff);

    ui->Value_Bedroom_2->setText("Lights: " +  onoff);
    ui->Value_Garage_2->setText("Lights: " +  onoff);
    ui->Value_Door->setText("State: ON");
}

void MainWindow::setAlarm(){
    ui->Frame_Alarm_1->setStyleSheet        ("background-color: rgb(100, 255, 100, 100);");
    ui->Frame_Alarm_2->setStyleSheet        ("background-color: rgb(100, 255, 100, 100);");
    ui->Frame_Alarm_3->setStyleSheet        ("background-color: rgb(100, 255, 100, 100);");
    ui->Frame_Alarm_4->setStyleSheet        ("background-color: rgb(100, 255, 100, 100);");


    QPixmap img_alarm("../piSmartHome/IMAGES/alarm");
    QPixmap IMG_alarm      = img_alarm.scaled       ( WIDTH_ALARM, HEIGHT_ALARM, Qt::IgnoreAspectRatio, Qt::FastTransformation);

    ui->Label_Alarm_1->setPixmap(IMG_alarm);
    ui->Label_Alarm_2->setPixmap(IMG_alarm);
    ui->Label_Alarm_3->setPixmap(IMG_alarm);
    ui->Label_Alarm_4->setPixmap(IMG_alarm);

    ui->Label_Alarm_1->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Label_Alarm_2->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Label_Alarm_3->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");
    ui->Label_Alarm_4->setStyleSheet("background-color: rgb(255, 0, 0,0);color: rgb(255,255,255,255); ");

}

void MainWindow::setDate_Time(){
    QFont font = ui->Time_Hours->font();
    font.setPointSize(14);
    ui->Time_Hours->setFont(font);
    ui->Time_Minutes->setFont(font);
    ui->Time_Seconds->setFont(font);

    ui->Time_Date->setText("17.08.2021");
    ui->Time_Hours->setText("14");
    ui->Time_Minutes->setText("26");
    ui->Time_Minutes->setText("11");
}


void MainWindow::setTemp(int temp){
    ui->Value_Temp->setText(QString::number(temp) + "°C" );
}

void MainWindow::setHumid(int humid){
    ui->Value_Humidity->setText(QString::number(humid) + "%" );
}

void MainWindow::setPress(uint8_t press1, uint8_t press2 ){
    uint16_t press;
    press = ((uint16_t)press1<<8)|press2;
    ui->Value_Press->setText( QString::number(1023) + "hPa" );
}

void MainWindow::setLight_Living(byte state){
    QString onoff;
    if(state==1)
        onoff="ON";
    else if(state==0)
        onoff="OFF";

    ui->Value_Livingroom->setText("Lights: " +  onoff);
    ui->Value_Livingroom_2->setText("Lights: " +  onoff);
}

void MainWindow::setLight_Bath(byte state){
    QString onoff;
    if(state==1)
        onoff="ON";
    else if(state==0)
        onoff="OFF";

    ui->Value_Bathroom->setText("Lights: " +  onoff);
    ui->Value_Bathroom_2->setText("Lights: " +  onoff);
}

void MainWindow::setLight_Bed(byte state){
    QString onoff;
    if(state==1)
        onoff="ON";
    else if(state==0)
        onoff="OFF";

    ui->Value_Bedroom->setText("Lights: " +  onoff);
    ui->Value_Bedroom_2->setText("Lights: " +  onoff);
}

void MainWindow::setLight_Kit(byte state){
    QString onoff;
    if(state==1)
        onoff="ON";
    else if(state==0)
        onoff="OFF";

    ui->Value_Kitchen->setText("Lights: " +  onoff);
    ui->Value_Kitchen_2->setText("Lights: " +  onoff);
}

void MainWindow::setLight_Hall(byte state){
    QString onoff;
    if(state==1)
        onoff="ON";
    else if(state==0)
        onoff="OFF";

    ui->Value_Hall->setText("Lights: " +  onoff);
    ui->Value_Hall_2->setText("Lights: " +  onoff);
}

void MainWindow::setLight_Gar(byte state){
    QString onoff;
    if(state==1)
        onoff="ON";
    else if(state==0)
        onoff="OFF";

    ui->Value_Garage->setText("Lights: " +  onoff);
    ui->Value_Garage_2->setText("Lights: " +  onoff);
}

void MainWindow::setFan(byte state){
    QString onoff;
    if(state==1)
        onoff="ON";
    else if(state==0)
        onoff="OFF";
    ui->Value_Fan->setText("State: " + onoff);
}

void MainWindow::setCM_Alarm( byte state){
    QString onoff;
    if(state==1)
        onoff="ON";
    else if(state==0)
        onoff="OFF";
    ui->Value_CM_Sensor->setText("State: " + onoff);
}

void MainWindow::setFlood(byte state){
    QString onoff;
    if(state==1)
        onoff="ON";
    else if(state==0)
        onoff="OFF";
    ui->Value_Flood->setText("State: " + onoff);
}

void MainWindow::setDoor(byte state){
    QString onoff;
    if(state==1)
        onoff="ON";
    else if(state==0)
        onoff="OFF";
    ui->Value_Door->setText("State: " + onoff);
}

void MainWindow::setCar(byte state){
    QString onoff;
    if(state==1)
        onoff="ON";
    else if(state==0)
        onoff="OFF";
    ui->Value_CarAl->setText("State: " + onoff);
}

void MainWindow::setHours(uint8_t hours, uint8_t minutes, uint8_t seconds){
    ui->Time_Hours->setText(QString::number(hours));
    ui->Time_Minutes->setText(QString::number(minutes));
    ui->Time_Seconds->setText(QString::number(seconds));
}

void MainWindow::setDate(uint8_t days, uint8_t months, uint8_t years){
    ui->Time_Date->setText(QString::number(days) + "." + QString::number(months) + ".20" + QString::number(years) );
}




















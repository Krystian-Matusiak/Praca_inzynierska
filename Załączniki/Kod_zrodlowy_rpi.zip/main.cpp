#include "mainwindow.h"

#include <QApplication>
#include <pthread.h>
#include <chrono>
#include <time.h>
#include <unistd.h>




unsigned char rx_frame[15];
unsigned char tx_frame[6] = { 0x01 , 0x03 , 0x00, 0x00, 0x00, 0x00 };

#define DEL10 10
#define DEL15 15
#define DEL20 20


void * txrx_loop(void *input){
    lora.opmodeLora();
    lora.opmode(OPMODE_STANDBY);
    lora.writeReg(RegPaRamp,(lora.readReg(RegPaRamp) & 0xF0) | 0x08); // set PA ramp-up time 50 uSec
    lora.configPower(23);
    int a=0;
    auto t1 = std::chrono::high_resolution_clock::now();
    auto t2 = std::chrono::high_resolution_clock::now();
    auto t = std::chrono::duration_cast<std::chrono::milliseconds>(t2-t1).count();

    while(1){

        //------------------------------------------------------------------------------------
        // CONNECTION WITH STM32F411
        tx_frame[1]=0x02;
        lora.Transmit(tx_frame,strlen( (char*)tx_frame) );

        lora.writeReg(REG_HOP_PERIOD,0x00);
        lora.writeReg(RegDioMapping1, MAP_DIO0_LORA_RXDONE|MAP_DIO1_LORA_NOP|MAP_DIO2_LORA_NOP);
        lora.writeReg(REG_IRQ_FLAGS, 0xFF);
        lora.writeReg(REG_IRQ_FLAGS_MASK, ~IRQ_LORA_RXDONE_MASK);
        lora.writeReg(REG_FIFO_RX_BASE_AD, 0x00);
        lora.writeReg(REG_FIFO_ADDR_PTR, 0x00);
        lora.opmode(OPMODE_RX);

        t=0;
        t1 = std::chrono::high_resolution_clock::now();
        while( t<300 && digitalRead(dio0)==0 ){
            t2 = std::chrono::high_resolution_clock::now();
            t = std::chrono::duration_cast<std::chrono::milliseconds>(t2-t1).count();
        }
        if(digitalRead(dio0)==1){
            lora.Receive(rx_frame);
        }


        //------------------------------------------------------------------------------------
        // CONNECTION WITH STM32F303
        tx_frame[1]=0x03;
        lora.Transmit(tx_frame,strlen( (char*)tx_frame) );

        lora.writeReg(REG_HOP_PERIOD,0x00);
        lora.writeReg(RegDioMapping1, MAP_DIO0_LORA_RXDONE|MAP_DIO1_LORA_NOP|MAP_DIO2_LORA_NOP);
        lora.writeReg(REG_IRQ_FLAGS, 0xFF);
        lora.writeReg(REG_IRQ_FLAGS_MASK, ~IRQ_LORA_RXDONE_MASK);
        lora.writeReg(REG_FIFO_RX_BASE_AD, 0x00);
        lora.writeReg(REG_FIFO_ADDR_PTR, 0x00);
        lora.opmode(OPMODE_RX);

        t=0;
        t1 = std::chrono::high_resolution_clock::now();
        while( t<300 && digitalRead(dio0)==0 ){
            t2 = std::chrono::high_resolution_clock::now();
            t = std::chrono::duration_cast<std::chrono::milliseconds>(t2-t1).count();
        }
        if(digitalRead(dio0)==1){
            lora.Receive(rx_frame);
        }
        //------------------------------------------------------------------------------------
    }
}

int main(int argc, char *argv[])
{
    wiringPiSetup () ;
    pinMode(ssPin, OUTPUT);
    pinMode(dio0, INPUT);
    pinMode(RST, OUTPUT);
    wiringPiSPISetup(CHANNEL, 500000);
    lora.SetupLoRa(868000000, 7);

    QApplication a(argc, argv);
    MainWindow w(rx_frame,tx_frame);

    pthread_t            tx_thread;
    pthread_create(&tx_thread, nullptr, txrx_loop, &w);
    w.show();

    int end = a.exec();

    pthread_cancel(tx_thread);
    pthread_join      (tx_thread,NULL);

    return end;
}
